<?php

namespace App\Models;

use App\Traits\HasCompany;

class RotationAutomateLog extends BaseModel
{
    use HasCompany;

    protected $table = 'rotation_automate_log';

}
